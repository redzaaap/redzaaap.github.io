import{_ as e,c,o}from"./index-DKXavtjx.js";const t={};function n(r,a){return o(),c("main")}const _=e(t,[["render",n]]);export{_ as default};
